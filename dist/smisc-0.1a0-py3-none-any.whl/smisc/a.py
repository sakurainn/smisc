def b():
    return 'c'