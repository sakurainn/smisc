from setuptools import find_packages, setup

setup(
    name='smisc',
    version='0.1-alpha',
    packages=find_packages(),
    author='sakurain',
    author_email='1457488119@qq.com',
    description='just utils',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Development Status :: 1 - Planning"
    ],
)
